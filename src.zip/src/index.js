import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import WordApp from './WordConvertor/WordApp'

ReactDOM.render(
  <React.StrictMode>
    <WordApp />
    {/* <App /> */}
  </React.StrictMode>,
  document.getElementById('root')
);